webpackHotUpdate(3,{

/***/ "./redux/actions/testAction.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RECEIVE_TESTS; });
/* unused harmony export FETCH_TESTS */
/* unused harmony export receiveTests */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return fetchTest; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_axios__ = __webpack_require__("../node_modules/axios/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_axios__);
var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();



var RECEIVE_TESTS = 'RECEIVE_TESTS';

var FETCH_TESTS = 'FETCH_TESTS';

var receiveTests = function receiveTests(tests) {
    return {
        type: RECEIVE_TESTS,
        payload: tests
    };
};

var fetchTest = function fetchTest() {
    var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

    return function (dispatch, getState) {
        __WEBPACK_IMPORTED_MODULE_0_axios___default.a.get('/api/test_all', {
            params: _extends({
                term: args && args.term || getState().testSchedule.termSelected || '',
                status: args && args.status || 'A'
            }, args)
        }).then(function (res) {
            if (res.data.is_error) {
                console.error(res.data.error_message);
                return window.alert(res.data.error_message);
            }
            dispatch(receiveTests(res.data.data));
        });
    };
};
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(RECEIVE_TESTS, 'RECEIVE_TESTS', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testAction.js');
    reactHotLoader.register(FETCH_TESTS, 'FETCH_TESTS', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testAction.js');
    reactHotLoader.register(receiveTests, 'receiveTests', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testAction.js');
    reactHotLoader.register(fetchTest, 'fetchTest', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testAction.js');
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/actions/testSchedule.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CHANGE_TERM; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return CHANGE_TYPE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return changeTerm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return changeType; });
(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();

var CHANGE_TERM = 'CHANGE_TERM';
var CHANGE_TYPE = 'CHANGE_TYPE';

var changeTerm = function changeTerm(term) {
    return {
        type: CHANGE_TERM,
        payload: term
    };
};

var changeType = function changeType(type) {
    return {
        type: CHANGE_TYPE,
        payload: type
    };
};
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(CHANGE_TERM, 'CHANGE_TERM', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testSchedule.js');
    reactHotLoader.register(CHANGE_TYPE, 'CHANGE_TYPE', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testSchedule.js');
    reactHotLoader.register(changeTerm, 'changeTerm', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testSchedule.js');
    reactHotLoader.register(changeType, 'changeType', '/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/testSchedule.js');
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/reducers/testReducer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (immutable) */ __webpack_exports__["a"] = testReducer;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions_testAction__ = __webpack_require__("./redux/actions/testAction.js");
(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();



function testReducer() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
    var action = arguments[1];

    switch (action.type) {
        case __WEBPACK_IMPORTED_MODULE_0__actions_testAction__["a" /* RECEIVE_TESTS */]:
            return action.payload;
        default:
            return state;
    }
    return state;
}
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(testReducer, "testReducer", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/reducers/testReducer.js");
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ }),

/***/ "./redux/reducers/testScheduleReducer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__actions_testSchedule__ = __webpack_require__("./redux/actions/testSchedule.js");
(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();



var _default = function _default() {
    var state = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {
        termSeleted: -1,
        typeSelected: -1
    };
    var action = arguments[1];

    switch (action.type) {
        case __WEBPACK_IMPORTED_MODULE_0__actions_testSchedule__["a" /* CHANGE_TERM */]:
            return Object.assign({}, state, { termSeleted: action.payload });
        case __WEBPACK_IMPORTED_MODULE_0__actions_testSchedule__["b" /* CHANGE_TYPE */]:
            return Object.assign({}, state, { typeSelected: action.payload });
        default:
            return state;
    }
    return state;
};

/* harmony default export */ __webpack_exports__["a"] = (_default);
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(_default, "default", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/reducers/testScheduleReducer.js");
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=3.bc5e229b3a6f1a3b6375.hot-update.js.map