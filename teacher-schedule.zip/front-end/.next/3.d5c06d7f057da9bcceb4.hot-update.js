webpackHotUpdate(3,{

/***/ "./redux/actions/termAction.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RECEIVE_TERM; });
/* unused harmony export receiveTerm */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return fetchTerms; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_axios__ = __webpack_require__("../node_modules/axios/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_axios___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_axios__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__scheduleAction__ = __webpack_require__("./redux/actions/scheduleAction.js");
(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();




var RECEIVE_TERM = 'RECEIVE_TERM';

var receiveTerm = function receiveTerm(terms) {
    return {
        type: RECEIVE_TERM,
        payload: terms
    };
};

var fetchTerms = function fetchTerms() {
    return function (dispatch, getState) {
        if (getState().terms.length > 0) return;
        __WEBPACK_IMPORTED_MODULE_0_axios___default.a.get('/api/term_all?status=A').then(function (res) {
            var data = res.data.data;
            dispatch(receiveTerm(data));
            // set default term
            if (data.length > 0 && getState().schedule.termSelected === -1) {
                dispatch(Object(__WEBPACK_IMPORTED_MODULE_1__scheduleAction__["n" /* selectTerm */])(data[0].term_id));
            }
        });
    };
};
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(RECEIVE_TERM, "RECEIVE_TERM", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/termAction.js");
    reactHotLoader.register(receiveTerm, "receiveTerm", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/termAction.js");
    reactHotLoader.register(fetchTerms, "fetchTerms", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/redux/actions/termAction.js");
    leaveModule(module);
})();

;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=3.d5c06d7f057da9bcceb4.hot-update.js.map