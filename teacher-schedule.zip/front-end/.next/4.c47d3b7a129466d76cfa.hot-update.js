webpackHotUpdate(4,{

/***/ "./pages/schedule/ScheduleContainer.js":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (immutable) */ __webpack_exports__["a"] = withConnect;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react_redux__ = __webpack_require__("../node_modules/react-redux/es/index.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__redux_actions_scheduleAction__ = __webpack_require__("./redux/actions/scheduleAction.js");
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__redux_actions_courseAction__ = __webpack_require__("./redux/actions/courseAction.js");
(function () {
    var enterModule = __webpack_require__("../node_modules/react-hot-loader/index.js").enterModule;

    enterModule && enterModule(module);
})();






var mapStateToProps = function mapStateToProps(state) {
    return {
        schedule: state.schedule,
        courses: state.courses,
        terms: state.terms,
        rooms: state.rooms
    };
};

var mapDispatchToProps = function mapDispatchToProps(dispatch) {
    return {
        changeTerm: function changeTerm(term) {
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_1__redux_actions_scheduleAction__["n" /* selectTerm */])(term));
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_2__redux_actions_courseAction__["b" /* fetchCourses */])({ term: term }));
        },
        changeRoom: function changeRoom(room) {
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_1__redux_actions_scheduleAction__["l" /* changeRoom */])(room));
            dispatch(Object(__WEBPACK_IMPORTED_MODULE_2__redux_actions_courseAction__["b" /* fetchCourses */])({ room: room }));
        }
    };
};

function withConnect(Component) {
    return Object(__WEBPACK_IMPORTED_MODULE_0_react_redux__["b" /* connect */])(mapStateToProps, mapDispatchToProps)(Component);
}
;

(function () {
    var reactHotLoader = __webpack_require__("../node_modules/react-hot-loader/index.js").default;

    var leaveModule = __webpack_require__("../node_modules/react-hot-loader/index.js").leaveModule;

    if (!reactHotLoader) {
        return;
    }

    reactHotLoader.register(mapStateToProps, "mapStateToProps", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/pages/schedule/ScheduleContainer.js");
    reactHotLoader.register(mapDispatchToProps, "mapDispatchToProps", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/pages/schedule/ScheduleContainer.js");
    reactHotLoader.register(withConnect, "withConnect", "/Users/puvanathvejabhuti/Projects/teacher_schedule/front-end/pages/schedule/ScheduleContainer.js");
    leaveModule(module);
})();

;
    (function (Component, route) {
      if(!Component) return
      if (false) return
      module.hot.accept()
      Component.__route = route

      if (module.hot.status() === 'idle') return

      var components = next.router.components
      for (var r in components) {
        if (!components.hasOwnProperty(r)) continue

        if (components[r].Component.__route === route) {
          next.router.update(r, Component)
        }
      }
    })(typeof __webpack_exports__ !== 'undefined' ? __webpack_exports__.default : (module.exports.default || module.exports), "/schedule/ScheduleContainer")
  
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__("../node_modules/webpack/buildin/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=4.c47d3b7a129466d76cfa.hot-update.js.map